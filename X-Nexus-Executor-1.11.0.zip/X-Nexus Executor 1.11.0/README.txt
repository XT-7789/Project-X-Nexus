X-Nexus Executor 1.11.0
=======================

Quick start
1. Extract the ZIP to a normal folder.
2. Run "X-Nexus Executor.exe".
3. For FPS controls, close Roblox before saving a frame-rate cap.
4. Use Performance > Start 5-minute recording to monitor PC CPU and memory usage while playing.
5. Open Performance > Capture for video recording and actual displayed-FPS capture.

FPS notes
- Display shortcuts fill the custom FPS field; click Save custom cap to apply it.
- The saved cap is a request. Actual Roblox FPS can be lower because of the game, graphics settings, CPU/GPU load, temperature, or Roblox limits.
- Press Shift+F5 (or Ctrl+Shift+F5) in Roblox to view its own FPS counter.

Performance notes
- The launcher records PC CPU and memory usage, not actual game FPS.
- A five-minute recording continues while X-Nexus is minimized.
- Export CSV before closing X-Nexus if you want to keep the latest recording.

Capture notes
- Video recording uses Windows Game Bar. X-Nexus switches to Roblox and sends Win+Alt+R; confirm the Windows recording timer appears.
- Video quality, game audio and microphone options are controlled by Windows Game Bar settings.
- Actual FPS capture uses the bundled Intel PresentMon helper for up to five minutes.
- FPS results include average displayed FPS and sampled 1% low. Raw frame data is saved locally as CSV.
- If the FPS tool is missing after an EXE-only update, use Download / verify FPS tool in the Capture page.

Privacy
- Performance recordings stay in memory until you choose Export CSV.
- Activity history is stored locally. Keys and script contents are excluded.
- Video is saved by Windows Game Bar. FPS capture CSV files remain in the local X-Nexus folder.
- X-Nexus does not upload recordings or performance captures.

Third-party component
- Intel PresentMon 2.5.1 is included under the MIT License.
- Its license is included in Tools\PresentMon-LICENSE.txt.

Project
https://github.com/XT-7789/Project-X-Nexus
