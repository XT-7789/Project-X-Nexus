X-Nexus Executor 1.10.1
=======================

Quick start
1. Extract the ZIP to a normal folder.
2. Run "X-Nexus Executor.exe".
3. For FPS controls, close Roblox before saving a frame-rate cap.
4. Use Performance > Start 5-minute recording to monitor PC CPU and memory usage while playing.

FPS notes
- Display shortcuts fill the custom FPS field; click Save custom cap to apply it.
- The saved cap is a request. Actual Roblox FPS can be lower because of the game, graphics settings, CPU/GPU load, temperature, or Roblox limits.
- Press Shift+F5 (or Ctrl+Shift+F5) in Roblox to view its own FPS counter.

Performance notes
- The launcher records PC CPU and memory usage, not actual game FPS.
- A five-minute recording continues while X-Nexus is minimized.
- Export CSV before closing X-Nexus if you want to keep the latest recording.

Privacy
- Performance recordings stay in memory until you choose Export CSV.
- Activity history is stored locally. Keys and script contents are excluded.

Project
https://github.com/XT-7789/Project-X-Nexus
